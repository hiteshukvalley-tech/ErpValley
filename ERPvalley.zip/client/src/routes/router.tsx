import { createBrowserRouter, type RouteObject } from 'react-router-dom'
import { PublicLayout } from '@/layouts/PublicLayout'
import { CaseStudiesPage } from '@/pages/company/CaseStudiesPage'
import { CaseStudyDetailPage } from '@/pages/company/CaseStudyDetailPage'
import {
  AboutPage,
  CareersPage,
  EngagementModelsPage,
  PartnersPage,
  ProcessPage,
  TechnologyPage,
  ValuesPage,
} from '@/pages/company/CompanyPages'
import { LeadershipPage, PortfolioPage, TeamPage } from '@/pages/company/PeoplePages'
import { DevelopersPage, FaqPage, HireDevelopersPage, PricingPage } from '@/pages/company/SalesPages'
import { DesignSystemPage } from '@/pages/DesignSystemPage'
import { HomePage } from '@/pages/HomePage'
import { IndustriesPage } from '@/pages/industries/IndustriesPage'
import { IndustryDetailPage } from '@/pages/industries/IndustryDetailPage'
import { ProductComparePage } from '@/pages/products/ProductComparePage'
import { ProductDetailPage } from '@/pages/products/ProductDetailPage'
import { ProductsOverviewPage } from '@/pages/products/ProductsOverviewPage'
import { CookiesPage, PrivacyPage, TermsPage } from '@/pages/legal/LegalPages'
import { RegistryPage } from '@/pages/RegistryPage'
import {
  BlogPage,
  BlogPostPage,
  GuidesPage,
  ReportsPage,
  WebinarsPage,
  WhitepapersPage,
} from '@/pages/resources/BlogPages'
import { NewsletterPage } from '@/pages/resources/NewsletterPage'
import { SearchPage } from '@/pages/resources/SearchPage'
import { ServerErrorPage } from '@/pages/ServerErrorPage'
import { ServiceDetailPage } from '@/pages/services/ServiceDetailPage'
import { ServicesPage } from '@/pages/services/ServicesPage'

export const routes: RouteObject[] = [
  {
    element: <PublicLayout />,
    errorElement: <ServerErrorPage />,
    children: [
      { index: true, element: <HomePage /> },
      { path: '500', element: <ServerErrorPage /> },
      { path: 'products', element: <ProductsOverviewPage /> },
      { path: 'products/compare', element: <ProductComparePage /> },
      { path: 'products/:slug', element: <ProductDetailPage /> },
      { path: 'industries', element: <IndustriesPage /> },
      { path: 'industries/:slug', element: <IndustryDetailPage /> },
      { path: 'services', element: <ServicesPage /> },
      { path: 'services/:slug', element: <ServiceDetailPage /> },
      { path: 'about', element: <AboutPage /> },
      { path: 'process', element: <ProcessPage /> },
      { path: 'technology', element: <TechnologyPage /> },
      { path: 'values', element: <ValuesPage /> },
      { path: 'team', element: <TeamPage /> },
      { path: 'leadership', element: <LeadershipPage /> },
      { path: 'partners', element: <PartnersPage /> },
      { path: 'careers', element: <CareersPage /> },
      { path: 'portfolio', element: <PortfolioPage /> },
      { path: 'engagement-models', element: <EngagementModelsPage /> },
      { path: 'hire-developers', element: <HireDevelopersPage /> },
      { path: 'developers', element: <DevelopersPage /> },
      { path: 'pricing', element: <PricingPage /> },
      { path: 'faq', element: <FaqPage /> },
      { path: 'case-studies', element: <CaseStudiesPage /> },
      { path: 'case-studies/:slug', element: <CaseStudyDetailPage /> },
      { path: 'blog', element: <BlogPage /> },
      { path: 'blog/:slug', element: <BlogPostPage /> },
      { path: 'guides', element: <GuidesPage /> },
      { path: 'whitepapers', element: <WhitepapersPage /> },
      { path: 'reports', element: <ReportsPage /> },
      { path: 'webinars', element: <WebinarsPage /> },
      { path: 'search', element: <SearchPage /> },
      { path: 'newsletter', element: <NewsletterPage /> },
      { path: 'privacy', element: <PrivacyPage /> },
      { path: 'terms', element: <TermsPage /> },
      { path: 'cookies', element: <CookiesPage /> },
      ...(import.meta.env.DEV ? [{ path: 'design-system', element: <DesignSystemPage /> }] : []),
      // Pages become explicit routes in later steps; until then the registry renders them.
      { path: '*', element: <RegistryPage /> },
    ],
  },
]

export const router = createBrowserRouter(routes)
