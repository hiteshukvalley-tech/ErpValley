import { BookOpen, CalendarClock, Info, Mail, Newspaper } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { useSearchParams } from 'react-router-dom'
import { PageHero } from '@/components/common/PageHero'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Section } from '@/components/ui/Section'
import { usePageMeta } from '@/hooks/usePageMeta'

const perks = [
  { icon: Newspaper, text: 'New articles and ERP guides' },
  { icon: BookOpen, text: 'Practical checklists for planning and rollout' },
  { icon: CalendarClock, text: 'Product updates and upcoming webinars' },
]

/**
 * Newsletter signup. Client-side validation only for now: the form is connected to the API in Step 6,
 * so it deliberately does not claim the address was saved.
 */
export function NewsletterPage() {
  usePageMeta('Newsletter', 'Subscribe to the ERPVALLEY newsletter for ERP guides, practical checklists and product updates, sent about once a month.')
  const [params] = useSearchParams()
  const [email, setEmail] = useState(params.get('email') ?? '')
  const [consent, setConsent] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState(false)

  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return setError('Enter a valid email address.')
    if (!consent) return setError('Please confirm you agree to receive emails.')
    setError('')
    setNotice(true)
  }

  return (
    <>
      <PageHero
        eyebrow="Newsletter"
        title="ERP insights in your inbox"
        description="Practical guides, checklists and product updates, about once a month. Unsubscribe any time."
      />
      <Section tone="alt">
        <div className="grid items-start gap-10 lg:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold">What you will receive</h2>
            <ul className="mt-6 space-y-4">
              {perks.map((p) => (
                <li key={p.text} className="flex items-center gap-3">
                  <span className="inline-flex size-10 items-center justify-center rounded-lg bg-primary-soft text-link">
                    <p.icon className="size-5" aria-hidden />
                  </span>
                  <span className="text-fg">{p.text}</span>
                </li>
              ))}
            </ul>
          </div>
          <Card className="p-6 sm:p-8">
            <form onSubmit={submit} noValidate>
              <label htmlFor="nl-email" className="text-sm font-semibold text-fg">Business email</label>
              <div className="relative mt-2">
                <Mail className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-muted" aria-hidden />
                <input
                  id="nl-email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  aria-invalid={!!error}
                  aria-describedby={error ? 'nl-error' : undefined}
                  className="h-11 w-full rounded-lg border border-line bg-surface pl-9 pr-3 text-fg focus:border-link focus:outline-none"
                  placeholder="you@company.com"
                />
              </div>
              <label className="mt-4 flex items-start gap-2.5 text-sm text-fg-muted">
                <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 size-4 accent-[var(--primary)]" />
                I agree to receive ERPVALLEY emails and understand I can unsubscribe at any time. See our privacy policy.
              </label>
              {error && (
                <p id="nl-error" role="alert" className="mt-3 text-sm font-medium text-rose-600 dark:text-rose-400">{error}</p>
              )}
              {notice && (
                <p role="status" className="mt-4 flex items-start gap-2 rounded-lg bg-primary-soft p-3 text-sm text-fg">
                  <Info className="mt-0.5 size-4 shrink-0 text-link" aria-hidden />
                  Newsletter signups are not open yet. Your address has not been stored. Please check back soon.
                </p>
              )}
              <Button type="submit" size="lg" className="mt-5 w-full">Subscribe</Button>
            </form>
          </Card>
        </div>
      </Section>
    </>
  )
}
